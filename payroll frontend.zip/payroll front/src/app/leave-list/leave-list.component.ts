import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Leave } from '../leave';
import { LeaveService } from '../leave.service';


@Component({
  selector: 'app-leave-list',
  templateUrl: './leave-list.component.html',
  styleUrls: ['./leave-list.component.css']
})
export class LeaveListComponent implements OnInit {

  leaves : Leave[];

  constructor(private leaveService: LeaveService,private router:Router) { }

  ngOnInit(): void {

    this.getLeaves();
  }
   private getLeaves(){
     this.leaveService.getLeavesList().subscribe(data => {
       this.leaves = data;
     });
   }
     deleteLeave(empId: number){
      this.leaveService.deleteLeave(empId).subscribe( data => {
        console.log(data);
        this.getLeaves();
      })
    }  
    Logout()
    {
      sessionStorage.clear();
      this.router.navigate(['login'])
    }  
///////////////////////
approveLeave(leave: Leave) {
  if (leave) {
    leave.leavestatus = 'Approved'; // Update status locally
    console.log(leave.leavestatus)
    this.leaveService.updateLeaveStatus(leave.empId, leave.leavestatus).subscribe(
      (data) => {
        console.log(data);
        leave.leavestatus = 'Approved'; // Update status locally again for immediate UI update

        this.getLeaves(); // Refresh leave list
      },
      (error) => {
        console.log('Error updating leave status:', error);
      }
    );
  }
}



denyLeave(leave: Leave) {
  if (leave) {
    leave.leavestatus = 'Denied'; // Update status locally
    this.leaveService.updateLeaveStatus(leave.empId, leave.leavestatus).subscribe(
      (data) => {
        console.log(data);
        leave.leavestatus = 'Denied'; // Update status locally again for immediate UI update
        this.getLeaves(); // Refresh leave list
      },
      (error) => {
        console.log('Error updating leave status:', error);
      }
    );
  }
}

    
    
    
    isAdmin(): boolean {
      // You should have a way to determine if the logged-in user is an admin.
      // You can use roles, permissions, or any other criteria.
      // For this example, let's assume you store isAdmin information in sessionStorage.
      console.log(sessionStorage.getItem('isAdmin'));
      return sessionStorage.getItem('isAdmin') === 'true';
      
    }

   }
  

